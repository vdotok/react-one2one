export const BASE_URL = "https://q-tenant.vdotok.dev/API/v0/";
export const PROJECT_ID = "392PS4E6";
